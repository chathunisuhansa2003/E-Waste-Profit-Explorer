# E-Waste Profit Explorer — four-page dashboard

Python 3.12 (64-bit) is required for the pinned dependencies. Models require scikit-learn 1.6.1. No models are retrained.

## Windows
Stop the previous demo server with Ctrl+C. Extract this archive and open the E_Waste_Dashboard folder. Double-click START_WINDOWS.bat. Keep its terminal open. Browse to http://127.0.0.1:8080.

Or use PowerShell in this folder:

```powershell
py -3.12 -m venv .venv312
.\.venv312\Scripts\python.exe -m pip install --only-binary=:all: -r requirements.txt
.\.venv312\Scripts\python.exe app.py
```

## Pages
- Profit Explorer: overview and the original interactive device prediction workflow.
- Model Comparison: actual saved CV and held-out test metrics for all four families. It compares results, not live predictions from all eight models. Only the final selected two model files were supplied in final outputs.
- Historical Evaluation: saved test records with actual/predicted values, errors, device-ID search, category and disagreement filters, pagination, category metrics, confusion matrix, and CSV export. It is not time-series validation, production history or a new evaluation.
- Best Models Prediction: runs the original frozen Random Forest regressor and Gradient Boosting classifier. Inputs are validated and stale results cleared on edits. Review examples are saved test records.

Profit is USD; acquisition cost is LKR. Tier cutoffs are loaded from feature_config.json (1.57 and 4.77). Labels are derived profit tiers, not independent operational priority. Profit estimates are not verified maximum purchase prices. Outside-reference-range notices compare with test records only. Models were selected with training CV before test evaluation; test findings have not been used to retrain them.

Do not replace model files with untrusted joblib files. The server binds to localhost only.
