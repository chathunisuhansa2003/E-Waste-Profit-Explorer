@echo off
cd /d "%~dp0"
py -3.12 --version >nul 2>&1
if errorlevel 1 (
 echo Please install Python 3.12 64-bit, then run this launcher again.
 pause
 exit /b 1
)
if not exist .venv312\Scripts\python.exe py -3.12 -m venv .venv312
if errorlevel 1 goto failed
.venv312\Scripts\python.exe -m pip install --only-binary=:all: -r requirements.txt
if errorlevel 1 goto failed
echo Open http://127.0.0.1:8080 in your browser.
.venv312\Scripts\python.exe app.py
pause
exit /b
:failed
echo Setup failed. See the error above.
pause
