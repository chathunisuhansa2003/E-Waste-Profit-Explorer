from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, math, io
from urllib.parse import urlparse, parse_qs
import pandas as pd
import numpy as np
import sklearn
import joblib

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / 'feature_config.json').read_text())
META = json.loads((ROOT / 'final_model_metadata.json').read_text())
if sklearn.__version__ != META['sklearn_version']:
    raise RuntimeError('Install requirements.txt first: models require scikit-learn ' + META['sklearn_version'])
REG = joblib.load(ROOT / 'final_profit_pipeline.joblib')
CLS = joblib.load(ROOT / 'final_priority_pipeline.joblib')
DATA = pd.read_csv(ROOT / 'final_test_predictions.csv')
RAW = CONFIG['raw_feature_columns']
CATS = {c: sorted(DATA[c].unique().tolist()) for c in CONFIG['categorical_features']}

def predict(values):
    row = {}
    for c in RAW:
        if c in CATS:
            if values.get(c) not in CATS[c]: raise ValueError('Invalid ' + c)
            row[c] = values[c]
        else:
            v = float(values[c])
            if not math.isfinite(v) or v < 0: raise ValueError(c + ' must be finite and non-negative')
            row[c] = v
    if row['weight_g'] <= 0: raise ValueError('Weight must be greater than zero')
    for metal in ['gold', 'silver', 'copper']:
        row[metal + '_yield_ratio'] = row[metal + '_yield_g'] / row['weight_g']
    if sum(row[c + '_yield_g'] for c in ['gold','silver','copper']) > row['weight_g']:
        raise ValueError('Total metal yield cannot exceed device weight')
    row['total_metal_ratio'] = sum(row[c + '_yield_ratio'] for c in ['gold','silver','copper'])
    row['log_weight_g'] = np.log1p(row['weight_g'])
    frame = pd.DataFrame([row])[CONFIG['feature_columns']]
    profit = float(REG.predict(frame)[0])
    tier = str(CLS.predict(frame)[0])
    policy = CONFIG['priority_policy']
    from_profit = 'Low' if profit <= policy['low_cutoff_usd'] else 'Medium' if profit <= policy['high_cutoff_usd'] else 'High'
    unusual = [c for c in RAW if c not in CATS and not DATA[c].min() <= row[c] <= DATA[c].max()]
    return {'profit':profit, 'tier':tier, 'profit_tier':from_profit, 'disagreement':tier != from_profit,
            'outside_reference_range':unusual}

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path in ['/', '/comparison', '/history', '/best-models']:
            body = (ROOT / 'index.html').read_bytes(); content = 'text/html'
        elif parsed.path == '/setup':
            body = json.dumps({'raw':RAW, 'categories':CATS, 'sample':DATA.iloc[0][RAW].to_dict(),
                              'examples':[{'id':r['device_id'],'values':r[RAW].to_dict()} for _,r in DATA.loc[DATA['tier_disagreement']].head(5).iterrows()],
                              'policy':CONFIG['priority_policy']}).encode(); content = 'application/json'
        elif parsed.path == '/evaluation':
            body = json.dumps({'test':pd.read_csv(ROOT/'held_out_test_comparison.csv').to_dict('records'),
                'cv':pd.read_csv(ROOT/'cv_model_comparison.csv').to_dict('records'),
                'category':pd.read_csv(ROOT/'selected_error_by_category.csv').to_dict('records'),
                'importance':pd.read_csv(ROOT/'selected_regression_permutation_importance.csv').to_dict('records'),
                'metadata':META}).encode(); content='application/json'
        elif parsed.path == '/records':
            q=parse_qs(parsed.query)
            frame=DATA.copy()
            search=q.get('search',[''])[0].strip().lower()
            if search: frame=frame[frame['device_id'].str.lower().str.contains(search,regex=False)]
            category=q.get('category',[''])[0]
            if category: frame=frame[frame['device_category']==category]
            if q.get('review',[''])[0]=='1': frame=frame[frame['tier_disagreement']]
            try: page=max(1,int(q.get('page',['1'])[0]))
            except ValueError: page=1
            columns=['device_id','device_category','condition','total_profit_usd','predicted_profit_usd','absolute_error_usd','Batch_Priority','predicted_priority','tier_disagreement']
            body=json.dumps({'total':len(frame),'page':page,'rows':frame.iloc[(page-1)*20:page*20][columns].to_dict('records')}).encode(); content='application/json'
        elif parsed.path == '/confusion.png':
            body=(ROOT/'selected_confusion_matrix.png').read_bytes(); content='image/png'
        elif parsed.path == '/download-results':
            body=(ROOT/'final_test_predictions.csv').read_bytes(); content='text/csv'
        else:
            self.send_error(404); return
        self.send_response(200); self.send_header('Content-Type',content); self.end_headers(); self.wfile.write(body)
    def do_POST(self):
        if self.path != '/predict': self.send_error(404); return
        try:
            size = int(self.headers.get('Content-Length',0))
            if size > 10000: raise ValueError('Request too large')
            result = predict(json.loads(self.rfile.read(size)))
            code=200
        except (ValueError, KeyError, TypeError) as error:
            result={'error':str(error)}; code=400
        self.send_response(code); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(json.dumps(result).encode())

if __name__ == '__main__':
    print('Open http://127.0.0.1:8080 — press Ctrl+C to stop', flush=True)
    ThreadingHTTPServer(('127.0.0.1',8080),Handler).serve_forever()
